#ifndef _COMPAT_H
#define _COMPAT_H 1

#include <stdarg.h>

int  vasprintf(char  **strp,  const  char *format, va_list ap);
#endif /* _COMPAT_H */
