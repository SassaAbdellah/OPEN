/*
 * Copyright 2010, 2011, 2012 mapsforge.org
 *
 * This program is free software: you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package org.mapsforge.android.maps.rendertheme.renderinstruction;

import java.util.List;
import java.util.Locale;

import org.mapsforge.android.maps.rendertheme.GraphicAdapter;
import org.mapsforge.android.maps.rendertheme.GraphicAdapter.Color;
import org.mapsforge.android.maps.rendertheme.RenderCallback;
import org.mapsforge.android.maps.rendertheme.RenderThemeHandler;
import org.mapsforge.core.graphics.Align;
import org.mapsforge.core.graphics.FontFamily;
import org.mapsforge.core.graphics.FontStyle;
import org.mapsforge.core.graphics.Paint;
import org.mapsforge.core.graphics.Style;
import org.mapsforge.core.model.Tag;
import org.xml.sax.Attributes;

/**
 * Represents a text along a polyline on the map.
 */
public final class PathText implements RenderInstruction {
	/**
	 * @param elementName
	 *            the name of the XML element.
	 * @param attributes
	 *            the attributes of the XML element.
	 * @return a new PathText with the given rendering attributes.
	 */
	public static PathText create(GraphicAdapter graphicAdapter, String elementName, Attributes attributes) {
		TextKey textKey = null;
		FontFamily fontFamily = FontFamily.DEFAULT;
		FontStyle fontStyle = FontStyle.NORMAL;
		float fontSize = 0;
		int fill = graphicAdapter.getColor(Color.BLACK);
		int stroke = graphicAdapter.getColor(Color.BLACK);
		float strokeWidth = 0;

		for (int i = 0; i < attributes.getLength(); ++i) {
			String name = attributes.getLocalName(i);
			String value = attributes.getValue(i);

			if ("k".equals(name)) {
				textKey = TextKey.getInstance(value);
			} else if ("font-family".equals(name)) {
				fontFamily = FontFamily.valueOf(value.toUpperCase(Locale.ENGLISH));
			} else if ("font-style".equals(name)) {
				fontStyle = FontStyle.valueOf(value.toUpperCase(Locale.ENGLISH));
			} else if ("font-size".equals(name)) {
				fontSize = Float.parseFloat(value);
			} else if ("fill".equals(name)) {
				fill = graphicAdapter.parseColor(value);
			} else if ("stroke".equals(name)) {
				stroke = graphicAdapter.parseColor(value);
			} else if ("stroke-width".equals(name)) {
				strokeWidth = Float.parseFloat(value);
			} else {
				RenderThemeHandler.logUnknownAttribute(elementName, name, value, i);
			}
		}

		validate(elementName, textKey, fontSize, strokeWidth);
		return new PathText(graphicAdapter, textKey, fontFamily, fontStyle, fontSize, fill, stroke, strokeWidth);
	}

	private static void validate(String elementName, TextKey textKey, float fontSize, float strokeWidth) {
		if (textKey == null) {
			throw new IllegalArgumentException("missing attribute k for element: " + elementName);
		} else if (fontSize < 0) {
			throw new IllegalArgumentException("font-size must not be negative: " + fontSize);
		} else if (strokeWidth < 0) {
			throw new IllegalArgumentException("stroke-width must not be negative: " + strokeWidth);
		}
	}

	private final float fontSize;
	private final Paint paint;
	private final Paint stroke;
	private final TextKey textKey;

	private PathText(GraphicAdapter graphicAdapter, TextKey textKey, FontFamily fontFamily, FontStyle fontStyle,
			float fontSize, int fill, int stroke, float strokeWidth) {
		super();

		this.textKey = textKey;

		this.paint = graphicAdapter.getPaint();
		this.paint.setTextAlign(Align.CENTER);
		this.paint.setTypeface(fontFamily, fontStyle);
		this.paint.setColor(fill);

		this.stroke = graphicAdapter.getPaint();
		this.stroke.setStyle(Style.STROKE);
		this.stroke.setTextAlign(Align.CENTER);
		this.stroke.setTypeface(fontFamily, fontStyle);
		this.stroke.setColor(stroke);
		this.stroke.setStrokeWidth(strokeWidth);

		this.fontSize = fontSize;
	}

	@Override
	public void destroy() {
		// do nothing
	}

	@Override
	public void renderNode(RenderCallback renderCallback, List<Tag> tags) {
		// do nothing
	}

	@Override
	public void renderWay(RenderCallback renderCallback, List<Tag> tags) {
		String caption = this.textKey.getValue(tags);
		if (caption == null) {
			return;
		}
		renderCallback.renderWayText(caption, this.paint, this.stroke);
	}

	@Override
	public void scaleStrokeWidth(float scaleFactor) {
		// do nothing
	}

	@Override
	public void scaleTextSize(float scaleFactor) {
		this.paint.setTextSize(this.fontSize * scaleFactor);
		this.stroke.setTextSize(this.fontSize * scaleFactor);
	}
}
