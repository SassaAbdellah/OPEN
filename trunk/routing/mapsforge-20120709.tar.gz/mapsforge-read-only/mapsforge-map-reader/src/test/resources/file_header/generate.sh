#!/bin/bash
osmosis --rx file=input.xml --mw file=output.map bbox=0.1,0.2,0.3,0.4 map-start-position=0.15,0.25 map-start-zoom=16 preferred-language=en comment=testcomment
