#!/bin/bash
osmosis --rx file=input.xml --mw file=output.map bbox=0,0,0.08,0.08 debug-file=true
