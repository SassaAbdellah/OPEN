#!/bin/bash
osmosis --rx file=input.xml --mw file=output.map bbox=0.99,0.99,1.01,1.01
