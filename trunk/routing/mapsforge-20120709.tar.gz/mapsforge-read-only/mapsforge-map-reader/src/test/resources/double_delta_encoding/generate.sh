#!/bin/bash
osmosis --rx file=input.xml --mw file=output.map bbox=-1,0,0,1 encoding=double
